# assignment 1
Due date: 2/10/2016 8:00 am CST. 
Please submit on Blackboard using the representative's account.
